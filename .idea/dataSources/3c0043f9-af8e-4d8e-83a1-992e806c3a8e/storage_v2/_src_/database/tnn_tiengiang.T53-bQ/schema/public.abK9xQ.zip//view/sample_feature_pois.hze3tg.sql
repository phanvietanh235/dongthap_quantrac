create view sample_feature_pois
            (id, ma_dvhc, kyhieu_mau, vitri_mau, "toado_X", "toado_Y", latlng, ngaylay_mau, khoiluong, ma_loaiquantrac,
             "LoaiQuanTrac")
as
SELECT "Mau_QT".id,
       "Mau_QT".ma_dvhc,
       "Mau_QT".kyhieu_mau,
       "Mau_QT".vitri_mau,
       "Mau_QT"."toado_X",
       "Mau_QT"."toado_Y",
       st_astext(st_transform(st_geomfromtext(concat('POINT(', "Mau_QT"."toado_X", ' ', "Mau_QT"."toado_Y", ')'), 9211),
                              4326)) AS latlng,
       "Mau_QT".ngaylay_mau,
       "Mau_QT".khoiluong,
       "Mau_QT".ma_loaiquantrac,
       lqt.name                      AS "LoaiQuanTrac"
FROM "Mau_QT"
         LEFT JOIN "LoaiQuanTrac" lqt ON "Mau_QT".ma_loaiquantrac = lqt.id;

alter table sample_feature_pois
    owner to postgres;

