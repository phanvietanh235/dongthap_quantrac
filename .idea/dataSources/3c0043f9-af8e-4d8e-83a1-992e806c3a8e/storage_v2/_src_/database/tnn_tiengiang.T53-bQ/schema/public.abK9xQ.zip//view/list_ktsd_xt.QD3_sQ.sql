create view list_ktsd_xt
            (ma_ctkt, "tenCongTrinh", "diaChiCongTrinh", "namXDVH", "coSoKTSD", "LoaiCongTrinh", "soGiayPhepXT",
             "tenDVHC", ma_dvhc, ma_dvhc_cha, "tenDoanhNghiep", "diaChiDoanhNghiep")
as
SELECT ctktsd.id           AS ma_ctkt,
       ctktsd."tenCongTrinh",
       ctktsd."diaChiCongTrinh",
       ctktsd."namXDVH",
       ctktsd."coSoKTSD",
       loaicongtrinh.name  AS "LoaiCongTrinh",
       thongtincpxt."soGiayPhepXT",
       district."tenDVHC",
       district.ma_dvhc,
       district.ma_dvhc_cha,
       doanhnghiep.name    AS "tenDoanhNghiep",
       doanhnghiep.address AS "diaChiDoanhNghiep"
FROM "CT_KTSD" ctktsd
         LEFT JOIN "ThongTinCP_XT" thongtincpxt ON thongtincpxt.ma_congtrinhktsd = ctktsd.id
         LEFT JOIN "District" district ON ctktsd.ma_dvhc = district.ma_dvhc
         LEFT JOIN "LoaiCongTrinh" loaicongtrinh ON ctktsd.ma_loaicongtrinh = loaicongtrinh.id
         LEFT JOIN "Enterprise" doanhnghiep ON thongtincpxt.ma_doanhnghiep = doanhnghiep.id
WHERE loaicongtrinh.id = 4;

alter table list_ktsd_xt
    owner to postgres;

