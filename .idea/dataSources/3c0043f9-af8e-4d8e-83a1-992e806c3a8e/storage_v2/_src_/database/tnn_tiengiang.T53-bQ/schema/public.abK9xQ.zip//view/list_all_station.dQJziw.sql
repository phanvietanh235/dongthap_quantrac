create view list_all_station
            (id, "soHieu", "TinhTrang", ten_ct, id_ct, diachi_ct, "maLoaiCongTrinh", "LoaiCongTrinh", type_ct,
             "tenDVHC", ma_dvhc, ma_dvhc_cha, luuvucsong_id, "LuuVucSong", tangchuanuoc_id, "TangChuaNuoc",
             doanhnghiep_id, doanhnghiep_name)
as
SELECT concat(diemktsd_ndd.id, '_ndd') AS id,
       diemktsd_ndd."soHieuGieng"      AS "soHieu",
       diemktsd_ndd."tinhTrangGieng"   AS "TinhTrang",
       ctktsd_1."tenCongTrinh"         AS ten_ct,
       ctktsd_1.id                     AS id_ct,
       ctktsd_1."diaChiCongTrinh"      AS diachi_ct,
       ctktsd_1.ma_loaicongtrinh       AS "maLoaiCongTrinh",
       loaicongtrinh_1.name            AS "LoaiCongTrinh",
       'ktsd_ndd'::text                AS type_ct,
       district_1."tenDVHC",
       district_1.ma_dvhc,
       district_1.ma_dvhc_cha,
       NULL::integer                   AS luuvucsong_id,
       NULL::character varying         AS "LuuVucSong",
       tangchuanuoc_1.id               AS tangchuanuoc_id,
       tangchuanuoc_1.name             AS "TangChuaNuoc",
       enterprise.id                   AS doanhnghiep_id,
       enterprise.name                 AS doanhnghiep_name
FROM "DiemKTSD_NDD" diemktsd_ndd
         LEFT JOIN "CT_KTSD" ctktsd_1 ON diemktsd_ndd.ma_congtrinhktsd = ctktsd_1.id
         LEFT JOIN "ThongTinCP_NDD" ttcp_ndd ON ctktsd_1.id = ttcp_ndd.ma_congtrinhktsd
         LEFT JOIN "Enterprise" enterprise ON ttcp_ndd.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiCongTrinh" loaicongtrinh_1 ON ctktsd_1.ma_loaicongtrinh = loaicongtrinh_1.id
         LEFT JOIN "District" district_1 ON ctktsd_1.ma_dvhc = district_1.ma_dvhc
         LEFT JOIN "TangChuaNuoc" tangchuanuoc_1 ON diemktsd_ndd.ma_tangchuanuoc = tangchuanuoc_1.id
UNION
SELECT concat(diemktsd_nm.id, '_nm') AS id,
       diemktsd_nm."soHieuDiem"      AS "soHieu",
       diemktsd_nm.tinhtrangkhaithac AS "TinhTrang",
       ctktsd_2."tenCongTrinh"       AS ten_ct,
       ctktsd_2.id                   AS id_ct,
       ctktsd_2."diaChiCongTrinh"    AS diachi_ct,
       ctktsd_2.ma_loaicongtrinh     AS "maLoaiCongTrinh",
       loaicongtrinh_2.name          AS "LoaiCongTrinh",
       'ktsd_nm'::text               AS type_ct,
       district_2."tenDVHC",
       district_2.ma_dvhc,
       district_2.ma_dvhc_cha,
       basin_2.id                    AS luuvucsong_id,
       basin_2.name                  AS "LuuVucSong",
       NULL::integer                 AS tangchuanuoc_id,
       NULL::character varying       AS "TangChuaNuoc",
       enterprise.id                 AS doanhnghiep_id,
       enterprise.name               AS doanhnghiep_name
FROM "DiemKTSD_NM" diemktsd_nm
         LEFT JOIN "CT_KTSD" ctktsd_2 ON diemktsd_nm.ma_congtrinhktsd = ctktsd_2.id
         LEFT JOIN "ThongTinCP_NM" ttcp_nm ON ctktsd_2.id = ttcp_nm.ma_congtrinhktsd
         LEFT JOIN "Enterprise" enterprise ON ttcp_nm.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiCongTrinh" loaicongtrinh_2 ON ctktsd_2.ma_loaicongtrinh = loaicongtrinh_2.id
         LEFT JOIN "District" district_2 ON ctktsd_2.ma_dvhc = district_2.ma_dvhc
         LEFT JOIN "Basin" basin_2 ON diemktsd_nm.ma_luuvucsong = basin_2.id
UNION
SELECT concat(diem_xt.id, '_xt')  AS id,
       diem_xt."soHieuDiem"       AS "soHieu",
       diem_xt.tinhtrangxathai    AS "TinhTrang",
       ctktsd_3."tenCongTrinh"    AS ten_ct,
       ctktsd_3.id                AS id_ct,
       ctktsd_3."diaChiCongTrinh" AS diachi_ct,
       ctktsd_3.ma_loaicongtrinh  AS "maLoaiCongTrinh",
       loaicongtrinh_3.name       AS "LoaiCongTrinh",
       'xt'::text                 AS type_ct,
       district_3."tenDVHC",
       district_3.ma_dvhc,
       district_3.ma_dvhc_cha,
       basin_3.id                 AS luuvucsong_id,
       basin_3.name               AS "LuuVucSong",
       NULL::integer              AS tangchuanuoc_id,
       NULL::character varying    AS "TangChuaNuoc",
       enterprise.id              AS doanhnghiep_id,
       enterprise.name            AS doanhnghiep_name
FROM "DiemXT" diem_xt
         LEFT JOIN "CT_KTSD" ctktsd_3 ON diem_xt.ma_congtrinhktsd = ctktsd_3.id
         LEFT JOIN "ThongTinCP_XT" ttcp_xt ON ctktsd_3.id = ttcp_xt.ma_congtrinhktsd
         LEFT JOIN "Enterprise" enterprise ON ttcp_xt.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiCongTrinh" loaicongtrinh_3 ON ctktsd_3.ma_loaicongtrinh = loaicongtrinh_3.id
         LEFT JOIN "District" district_3 ON ctktsd_3.ma_dvhc = district_3.ma_dvhc
         LEFT JOIN "Basin" basin_3 ON diem_xt.ma_luuvucsong = basin_3.id
UNION
SELECT concat(diem_td.id, '_td')  AS id,
       diem_td."soHieuGiengTD"    AS "soHieu",
       diem_td.tinhtrangthamdo    AS "TinhTrang",
       ctktsd_4."tenCongTrinh"    AS ten_ct,
       ctktsd_4.id                AS id_ct,
       ctktsd_4."diaChiCongTrinh" AS diachi_ct,
       ctktsd_4.ma_loaicongtrinh  AS "maLoaiCongTrinh",
       loaicongtrinh_4.name       AS "LoaiCongTrinh",
       'td'::text                 AS type_ct,
       district_4."tenDVHC",
       district_4.ma_dvhc,
       district_4.ma_dvhc_cha,
       NULL::integer              AS luuvucsong_id,
       NULL::character varying    AS "LuuVucSong",
       tangchuanuoc_4.id          AS tangchuanuoc_id,
       tangchuanuoc_4.name        AS "TangChuaNuoc",
       enterprise.id              AS doanhnghiep_id,
       enterprise.name            AS doanhnghiep_name
FROM "DiemTD_NDD" diem_td
         LEFT JOIN "CT_KTSD" ctktsd_4 ON diem_td.ma_congtrinhktsd = ctktsd_4.id
         LEFT JOIN "ThongTinCP_TD" ttcp_td ON ctktsd_4.id = ttcp_td.ma_congtrinhktsd
         LEFT JOIN "Enterprise" enterprise ON ttcp_td.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiCongTrinh" loaicongtrinh_4 ON ctktsd_4.ma_loaicongtrinh = loaicongtrinh_4.id
         LEFT JOIN "District" district_4 ON ctktsd_4.ma_dvhc = district_4.ma_dvhc
         LEFT JOIN "TangChuaNuoc" tangchuanuoc_4 ON diem_td.ma_tangchuanuoc = tangchuanuoc_4.id;

alter table list_all_station
    owner to postgres;

