create function st_rotatez(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_Rotate($1, $2)
$$;

comment on function st_rotatez(geometry, double precision) is 'args: geomA, rotRadians - Rotates a geometry about the Z axis.';

alter function st_rotatez(geometry, double precision) owner to postgres;

