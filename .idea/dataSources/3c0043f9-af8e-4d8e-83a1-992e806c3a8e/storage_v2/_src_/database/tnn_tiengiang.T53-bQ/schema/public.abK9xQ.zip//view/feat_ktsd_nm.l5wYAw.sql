create view feat_ktsd_nm
            (idgieng, ma_congtrinhktsd, "toaDoX", "toaDoY", latlng, "soHieuDiem", "luuLuongKTLN", "luuLuongKTLNMuaKho",
             "cheDoKT", "nguonKhaiThac", "phuongThucKT", "vungBHVS", "moTaVungBHVS", tinhtrangkhaithac, macongtrinh,
             "tenCongTrinh", "tenDVHC", ma_dvhc_cha, "diaChiCongTrinh", "coSoKTSD", "namXDVH", "thoiHanKTSD", idgp,
             ma_doanhnghiep, "TenDoanhNghiep", "LoaiGiayPhep", "soGiayPhepNM", "ngayCapPhep", "tinhTrangGiayPhep")
as
SELECT diemktsd_nm.id                                                                                                AS idgieng,
       diemktsd_nm.ma_congtrinhktsd,
       diemktsd_nm."toaDoX",
       diemktsd_nm."toaDoY",
       st_astext(st_transform(
               st_geomfromtext(concat('POINT(', diemktsd_nm."toaDoX", ' ', diemktsd_nm."toaDoY", ')'), 9211),
               4326))                                                                                                AS latlng,
       diemktsd_nm."soHieuDiem",
       diemktsd_nm."luuLuongKTLN",
       diemktsd_nm."luuLuongKTLNMuaKho",
       diemktsd_nm."cheDoKT",
       diemktsd_nm."nguonKhaiThac",
       diemktsd_nm."phuongThucKT",
       diemktsd_nm."vungBHVS",
       diemktsd_nm."moTaVungBHVS",
       diemktsd_nm.tinhtrangkhaithac,
       ctkt_sd.id                                                                                                    AS macongtrinh,
       ctkt_sd."tenCongTrinh",
       district."tenDVHC",
       district.ma_dvhc_cha,
       ctkt_sd."diaChiCongTrinh",
       ctkt_sd."coSoKTSD",
       ctkt_sd."namXDVH",
       ctkt_sd."thoiHanKTSD",
       thongtincp_nm.id                                                                                              AS idgp,
       thongtincp_nm.ma_doanhnghiep,
       enterprise.name                                                                                               AS "TenDoanhNghiep",
       loaigiayphep.name                                                                                             AS "LoaiGiayPhep",
       thongtincp_nm."soGiayPhepNM",
       thongtincp_nm."ngayCapPhep",
       thongtincp_nm."tinhTrangGiayPhep"
FROM "DiemKTSD_NM" diemktsd_nm
         LEFT JOIN "CT_KTSD" ctkt_sd ON diemktsd_nm.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "District" district ON ctkt_sd.ma_dvhc = district.ma_dvhc
         LEFT JOIN "ThongTinCP_NM" thongtincp_nm ON thongtincp_nm.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "Enterprise" enterprise ON thongtincp_nm.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiGiayPhep" loaigiayphep ON thongtincp_nm.ma_loaigiayphep = loaigiayphep.id
WHERE thongtincp_nm."tinhTrangGiayPhep" = diemktsd_nm.tinhtrangkhaithac;

alter table feat_ktsd_nm
    owner to postgres;

