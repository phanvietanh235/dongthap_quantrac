create view feat_ktsd_ndd
            (idgieng, ma_congtrinhktsd, "toaDoX", "toaDoY", latlng, "soHieuGieng", "cheDoKhaiThac", "ketCauGiengKhoan",
             "luuLuongKTCP", "tinhTrangGieng", "vungBHVS", "moTaVungBHVS", macongtrinh, "tenCongTrinh", "tenDVHC",
             ma_dvhc_cha, "diaChiCongTrinh", "coSoKTSD", "namXDVH", "thoiHanKTSD", idgp, ma_doanhnghiep,
             "TenDoanhNghiep", "LoaiGiayPhep", "soGiayPhepNDD", "ngayCapPhep", "tinhTrangGiayPhep")
as
SELECT diemktsd_ndd.id   AS idgieng,
       diemktsd_ndd.ma_congtrinhktsd,
       diemktsd_ndd."toaDoX",
       diemktsd_ndd."toaDoY",
       st_astext(st_transform(
               st_geomfromtext(concat('POINT(', diemktsd_ndd."toaDoX", ' ', diemktsd_ndd."toaDoY", ')'), 9211),
               4326))    AS latlng,
       diemktsd_ndd."soHieuGieng",
       diemktsd_ndd."cheDoKhaiThac",
       diemktsd_ndd."ketCauGiengKhoan",
       diemktsd_ndd."luuLuongKTCP",
       diemktsd_ndd."tinhTrangGieng",
       diemktsd_ndd."vungBHVS",
       diemktsd_ndd."moTaVungBHVS",
       ctkt_sd.id        AS macongtrinh,
       ctkt_sd."tenCongTrinh",
       district."tenDVHC",
       district.ma_dvhc_cha,
       ctkt_sd."diaChiCongTrinh",
       ctkt_sd."coSoKTSD",
       ctkt_sd."namXDVH",
       ctkt_sd."thoiHanKTSD",
       thongtincp_ndd.id AS idgp,
       thongtincp_ndd.ma_doanhnghiep,
       enterprise.name   AS "TenDoanhNghiep",
       loaigiayphep.name AS "LoaiGiayPhep",
       thongtincp_ndd."soGiayPhepNDD",
       thongtincp_ndd."ngayCapPhep",
       thongtincp_ndd."tinhTrangGiayPhep"
FROM "DiemKTSD_NDD" diemktsd_ndd
         LEFT JOIN "CT_KTSD" ctkt_sd ON diemktsd_ndd.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "District" district ON ctkt_sd.ma_dvhc = district.ma_dvhc
         LEFT JOIN "ThongTinCP_NDD" thongtincp_ndd ON thongtincp_ndd.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "Enterprise" enterprise ON thongtincp_ndd.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiGiayPhep" loaigiayphep ON thongtincp_ndd.ma_loaigiayphep = loaigiayphep.id
WHERE thongtincp_ndd."tinhTrangGiayPhep" = diemktsd_ndd."tinhTrangGieng";

alter table feat_ktsd_ndd
    owner to postgres;

