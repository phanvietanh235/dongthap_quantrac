create view list_ktsd_ndd
            (ma_ctkt, "tenCongTrinh", "diaChiCongTrinh", "namXDVH", "coSoKTSD", "LoaiCongTrinh", "soGiayPhepNDD",
             "tenDVHC", ma_dvhc, ma_dvhc_cha, "tenDoanhNghiep")
as
SELECT ctktsd.id          AS ma_ctkt,
       ctktsd."tenCongTrinh",
       ctktsd."diaChiCongTrinh",
       ctktsd."namXDVH",
       ctktsd."coSoKTSD",
       loaicongtrinh.name AS "LoaiCongTrinh",
       thongtincpndd."soGiayPhepNDD",
       district."tenDVHC",
       district.ma_dvhc,
       district.ma_dvhc_cha,
       doanhnghiep.name   AS "tenDoanhNghiep"
FROM "CT_KTSD" ctktsd
         LEFT JOIN "ThongTinCP_NDD" thongtincpndd ON thongtincpndd.ma_congtrinhktsd = ctktsd.id
         LEFT JOIN "District" district ON ctktsd.ma_dvhc = district.ma_dvhc
         LEFT JOIN "LoaiCongTrinh" loaicongtrinh ON ctktsd.ma_loaicongtrinh = loaicongtrinh.id
         LEFT JOIN "Enterprise" doanhnghiep ON thongtincpndd.ma_doanhnghiep = doanhnghiep.id
WHERE loaicongtrinh.id = 2;

alter table list_ktsd_ndd
    owner to postgres;

