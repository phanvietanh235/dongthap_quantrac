create view feat_ktsd_xt
            (idgieng, ma_congtrinhktsd, "toaDoX", "toaDoY", latlng, "soHieuDiem", "luuLuongXT", "cheDoXT",
             "nguonTiepNhanNT", "mucDichXT", "phuongThucXT", tinhtrangxathai, macongtrinh, "tenCongTrinh", "tenDVHC",
             ma_dvhc_cha, "diaChiCongTrinh", "coSoKTSD", "namXDVH", "thoiHanKTSD", idgp, ma_doanhnghiep,
             "TenDoanhNghiep", "LoaiGiayPhep", "soGiayPhepXT", "ngayCapPhep", "tinhTrangGiayPhep")
as
SELECT diemxt.id                     AS idgieng,
       diemxt.ma_congtrinhktsd,
       diemxt."toaDoX",
       diemxt."toaDoY",
       st_astext(st_transform(st_geomfromtext(concat('POINT(', diemxt."toaDoX", ' ', diemxt."toaDoY", ')'), 9211),
                              4326)) AS latlng,
       diemxt."soHieuDiem",
       diemxt."luuLuongXT",
       diemxt."cheDoXT",
       diemxt."nguonTiepNhanNT",
       diemxt."mucDichXT",
       diemxt."phuongThucXT",
       diemxt.tinhtrangxathai,
       ctkt_sd.id                    AS macongtrinh,
       ctkt_sd."tenCongTrinh",
       district."tenDVHC",
       district.ma_dvhc_cha,
       ctkt_sd."diaChiCongTrinh",
       ctkt_sd."coSoKTSD",
       ctkt_sd."namXDVH",
       ctkt_sd."thoiHanKTSD",
       thongtincp_xt.id              AS idgp,
       thongtincp_xt.ma_doanhnghiep,
       enterprise.name               AS "TenDoanhNghiep",
       loaigiayphep.name             AS "LoaiGiayPhep",
       thongtincp_xt."soGiayPhepXT",
       thongtincp_xt."ngayCapPhep",
       thongtincp_xt."tinhTrangGiayPhep"
FROM "DiemXT" diemxt
         LEFT JOIN "CT_KTSD" ctkt_sd ON diemxt.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "District" district ON ctkt_sd.ma_dvhc = district.ma_dvhc
         LEFT JOIN "ThongTinCP_XT" thongtincp_xt ON thongtincp_xt.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "Enterprise" enterprise ON thongtincp_xt.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiGiayPhep" loaigiayphep ON thongtincp_xt.ma_loaigiayphep = loaigiayphep.id
WHERE thongtincp_xt."tinhTrangGiayPhep" = diemxt.tinhtrangxathai;

alter table feat_ktsd_xt
    owner to postgres;

