create view list_giengqt_ndd
            (ma_ctkt, "tenCongTrinh", "diaChiCongTrinh", "coSoKTSD", "LoaiCongTrinh", "tenDVHC", ma_dvhc, ma_dvhc_cha,
             "TangChuaNuoc", "TangChuaNuoc_name", "idSohieu", "Sohieu", "ToadoY", "ToadoX")
as
SELECT ctktsd.id                 AS ma_ctkt,
       ctktsd."tenCongTrinh",
       ctktsd."diaChiCongTrinh",
       ctktsd."coSoKTSD",
       loaicongtrinh.name        AS "LoaiCongTrinh",
       district."tenDVHC",
       district.ma_dvhc,
       district.ma_dvhc_cha,
       tangchuanuoc.id           AS "TangChuaNuoc",
       tangchuanuoc.name         AS "TangChuaNuoc_name",
       giengqt_ndd.id            AS "idSohieu",
       giengqt_ndd.sohieugiengqt AS "Sohieu",
       giengqt_ndd."coordY"      AS "ToadoY",
       giengqt_ndd."coordX"      AS "ToadoX"
FROM "CT_KTSD" ctktsd
         LEFT JOIN "GiengQT_NDD" giengqt_ndd ON ctktsd.id = giengqt_ndd.ma_congtrinhktsd
         LEFT JOIN "District" district ON ctktsd.ma_dvhc = district.ma_dvhc
         LEFT JOIN "LoaiCongTrinh" loaicongtrinh ON ctktsd.ma_loaicongtrinh = loaicongtrinh.id
         LEFT JOIN "TangChuaNuoc" tangchuanuoc ON giengqt_ndd.ma_tangchuanuoc = tangchuanuoc.id
WHERE loaicongtrinh.id = 6;

alter table list_giengqt_ndd
    owner to postgres;

