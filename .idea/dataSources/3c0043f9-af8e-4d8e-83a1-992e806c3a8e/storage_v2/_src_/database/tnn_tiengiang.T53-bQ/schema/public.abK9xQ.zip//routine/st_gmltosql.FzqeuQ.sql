create function st_gmltosql(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_GeomFromGML($1, 0)
$$;

alter function st_gmltosql(text) owner to postgres;

