create view feat_ktsd_td
            (idgieng, ma_congtrinhktsd, "toaDoX", "toaDoY", latlng, "soHieuGiengTD", "chieuSauDuKienTD",
             "soLuongGiengTD", "vungBHVS", "moTaVungBHVS", tinhtrangthamdo, macongtrinh, "tenCongTrinh", "tenDVHC",
             ma_dvhc_cha, "diaChiCongTrinh", "coSoKTSD", "namXDVH", "thoiHanKTSD", idgp, ma_doanhnghiep,
             "TenDoanhNghiep", "LoaiGiayPhep", "soGiayPhepTD", "ngayCapPhep", "tinhTrangGiayPhep")
as
SELECT diem_td.id                    AS idgieng,
       diem_td.ma_congtrinhktsd,
       diem_td."toaDoX",
       diem_td."toaDoY",
       st_astext(st_transform(st_geomfromtext(concat('POINT(', diem_td."toaDoX", ' ', diem_td."toaDoY", ')'), 9211),
                              4326)) AS latlng,
       diem_td."soHieuGiengTD",
       diem_td."chieuSauDuKienTD",
       diem_td."soLuongGiengTD",
       diem_td."vungBHVS",
       diem_td."moTaVungBHVS",
       diem_td.tinhtrangthamdo,
       ctkt_sd.id                    AS macongtrinh,
       ctkt_sd."tenCongTrinh",
       district."tenDVHC",
       district.ma_dvhc_cha,
       ctkt_sd."diaChiCongTrinh",
       ctkt_sd."coSoKTSD",
       ctkt_sd."namXDVH",
       ctkt_sd."thoiHanKTSD",
       thongtincp_td.id              AS idgp,
       thongtincp_td.ma_doanhnghiep,
       enterprise.name               AS "TenDoanhNghiep",
       loaigiayphep.name             AS "LoaiGiayPhep",
       thongtincp_td."soGiayPhepTD",
       thongtincp_td."ngayCapPhep",
       thongtincp_td."tinhTrangGiayPhep"
FROM "DiemTD_NDD" diem_td
         LEFT JOIN "CT_KTSD" ctkt_sd ON diem_td.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "District" district ON ctkt_sd.ma_dvhc = district.ma_dvhc
         LEFT JOIN "ThongTinCP_TD" thongtincp_td ON thongtincp_td.ma_congtrinhktsd = ctkt_sd.id
         LEFT JOIN "Enterprise" enterprise ON thongtincp_td.ma_doanhnghiep = enterprise.id
         LEFT JOIN "LoaiGiayPhep" loaigiayphep ON thongtincp_td.ma_loaigiayphep = loaigiayphep.id
WHERE thongtincp_td."tinhTrangGiayPhep" = diem_td.tinhtrangthamdo;

alter table feat_ktsd_td
    owner to postgres;

